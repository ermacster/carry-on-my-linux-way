# scripting-bash.md

(Добавь содержимое сюда)