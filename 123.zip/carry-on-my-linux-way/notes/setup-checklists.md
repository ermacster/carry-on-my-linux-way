# setup-checklists.md

(Добавь содержимое сюда)